import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase.from('athlete_settings').select('*').eq('id', 1).single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'PUT') {
      const ftp = Number(req.body?.ftp);
      if (!Number.isFinite(ftp) || ftp < 50 || ftp > 700) return res.status(400).json({ error: 'FTP must be between 50 and 700 watts.' });
      const { data, error } = await supabase.from('athlete_settings').update({ ftp, updated_at: new Date().toISOString() }).eq('id', 1).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (error) {
    console.error('Settings API error:', error);
    return res.status(500).json({ error: error.message });
  }
}
