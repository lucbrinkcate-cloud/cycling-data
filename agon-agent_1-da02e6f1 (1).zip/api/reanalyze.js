import supabase from './db-client.js';
import { analyzeRide } from './lib/ride-analysis.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const id = Number(req.body?.id), ftp = Number(req.body?.ftp);
    if (!id || !ftp) return res.status(400).json({ error: 'Ride id and FTP are required.' });
    const { data: ride, error: readError } = await supabase.from('rides').select('*').eq('id', id).single();
    if (readError) throw readError;
    if (!Array.isArray(ride.samples) || ride.samples.length < 2) return res.status(400).json({ error: 'This ride has no usable samples.' });
    if (ride.samples.length < 300 || !ride.analysis?.version) return res.status(409).json({ error: 'This legacy ride was stored at reduced resolution. Re-upload the original FIT file for accurate analysis.' });
    const analysis = analyzeRide(ride.samples, ftp);
    const { data, error } = await supabase.from('rides').update({ analysis, summary: analysis.summary }).eq('id', id).select().single();
    if (error) throw error;
    return res.status(200).json(data);
  } catch (error) {
    console.error('Reanalysis API error:', error);
    return res.status(500).json({ error: error.message });
  }
}
