import supabase from './db-client.js';
import FitParser from 'fit-file-parser';
import { analyzeRide } from './lib/ride-analysis.js';

const cors = (res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
};

const fitParse = (buffer) => new Promise((resolve, reject) => {
  const parser = new FitParser({ force: true, speedUnit: 'km/h', lengthUnit: 'm', temperatureUnit: 'celsius', elapsedRecordField: true, mode: 'list' });
  parser.parse(buffer, (error, data) => error ? reject(error) : resolve(data));
});

const num = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;
const movingAverage = (values, span) => values.map((_, i) => {
  const slice = values.slice(Math.max(0, i - span + 1), i + 1);
  return slice.reduce((sum, value) => sum + value, 0) / slice.length;
});

function analyze(samples, ftp) {
  if (!samples.length) return { intervals: [], climbs: [], sprints: [], zones: [], trainingLoad: 0 };
  const powers = samples.map(s => num(s.power));
  const smoothPower = movingAverage(powers, 5);
  const groups = [];
  let start = 0;
  for (let i = 1; i <= samples.length; i++) {
    const previousZone = Math.min(5, Math.floor(smoothPower[i - 1] / Math.max(1, ftp) * 5));
    const nextZone = i < samples.length ? Math.min(5, Math.floor(smoothPower[i] / Math.max(1, ftp) * 5)) : -1;
    if (nextZone !== previousZone) {
      if (i - start >= 3) groups.push({ start, end: i - 1, zone: previousZone + 1 });
      start = i;
    }
  }
  const intervals = groups.filter(g => g.zone >= 4).map((g, index) => {
    const section = samples.slice(g.start, g.end + 1);
    return { id: index + 1, type: g.zone >= 5 ? 'Anaerobic' : 'Threshold', start: g.start, end: g.end, duration: num(section.at(-1)?.elapsed) - num(section[0]?.elapsed), avgPower: Math.round(section.reduce((a,s)=>a+num(s.power),0)/section.length), avgHr: Math.round(section.reduce((a,s)=>a+num(s.heart_rate),0)/section.length) };
  });
  const climbs = [];
  let climbStart = null;
  samples.forEach((sample, i) => {
    const rising = i > 0 && num(sample.altitude) > num(samples[i - 1].altitude);
    if (rising && climbStart === null) climbStart = i - 1;
    if ((!rising || i === samples.length - 1) && climbStart !== null) {
      const end = rising ? i : i - 1;
      const gain = num(samples[end].altitude) - num(samples[climbStart].altitude);
      if (end - climbStart >= 3 && gain > 8) climbs.push({ start: climbStart, end, gain: Math.round(gain), distance: +(num(samples[end].distance)-num(samples[climbStart].distance)).toFixed(1), grade: +((gain/Math.max(1,(num(samples[end].distance)-num(samples[climbStart].distance))*1000))*100).toFixed(1) });
      climbStart = null;
    }
  });
  const sprints = samples.map((s,i)=>({i,p:num(s.power)})).filter(x=>x.p > ftp*1.35).sort((a,b)=>b.p-a.p).slice(0,3).map((x,index)=>({ id:index+1, index:x.i, power:Math.round(x.p), speed:+num(samples[x.i].speed).toFixed(1), at:+num(samples[x.i].distance).toFixed(1) }));
  const zoneSeconds = [0,0,0,0,0];
  samples.forEach((s,i) => { const duration = i ? Math.max(0, num(s.elapsed)-num(samples[i-1].elapsed)) : 0; zoneSeconds[Math.min(4,Math.floor(num(s.power)/Math.max(1,ftp)*5))] += duration; });
  const zones = zoneSeconds.map((seconds,i)=>({ zone:i+1, seconds:Math.round(seconds) }));
  const durationHours = Math.max(0, num(samples.at(-1)?.elapsed)) / 3600;
  const avgPower = powers.reduce((a,b)=>a+b,0)/powers.length;
  const intensity = avgPower / Math.max(1, ftp);
  return { intervals: intervals.slice(0,8), climbs: climbs.slice(0,6), sprints, zones, trainingLoad: Math.round(durationHours * intensity * intensity * 100) };
}

function normalizeRecords(data) {
  const records = data?.records || data?.activity?.sessions?.flatMap(s => s.laps?.flatMap(l => l.records || []) || []) || [];
  const firstTime = records[0]?.timestamp ? new Date(records[0].timestamp).getTime() : Date.now();
  return records.map((r, index) => ({
    elapsed: r.elapsed_time != null ? num(r.elapsed_time) : r.timestamp ? (new Date(r.timestamp).getTime()-firstTime)/1000 : index,
    distance: num(r.distance) / 1000, altitude: num(r.altitude), speed: num(r.speed), power: num(r.power),
    heart_rate: num(r.heart_rate), cadence: num(r.cadence), latitude: num(r.position_lat), longitude: num(r.position_long)
  })).filter((sample, i, all) => i === 0 || sample.elapsed > all[i - 1].elapsed);
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      let query = supabase.from('rides').select('*').order('started_at', { ascending: false });
      if (req.query.id) query = query.eq('id', req.query.id);
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(req.query.id ? data?.[0] || null : data);
    }
    if (req.method === 'POST') {
      const { fileName, fileBase64, ftp = 285 } = req.body || {};
      if (!fileBase64 || !fileName?.toLowerCase().endsWith('.fit')) return res.status(400).json({ error: 'Choose a valid .fit file.' });
      const parsed = await fitParse(Buffer.from(fileBase64, 'base64'));
      const samples = normalizeRecords(parsed);
      if (samples.length < 2) return res.status(400).json({ error: 'No ride samples were found in this FIT file.' });
      const analysis = analyzeRide(samples, num(ftp, 285));
      const summary = analysis.summary;
      const title = fileName.replace(/\.fit$/i,'').replace(/[-_]+/g,' ').replace(/\b\w/g,c=>c.toUpperCase());
      const ride = { title, started_at: parsed?.activity?.timestamp || parsed?.sessions?.[0]?.start_time || new Date().toISOString(), summary, samples, analysis, source_file: fileName };
      const { data, error } = await supabase.from('rides').insert(ride).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'Ride id is required.' });
      const { error } = await supabase.from('rides').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (error) {
    console.error('Rides API error:', error);
    return res.status(500).json({ error: error.message || 'Unable to process ride.' });
  }
}
