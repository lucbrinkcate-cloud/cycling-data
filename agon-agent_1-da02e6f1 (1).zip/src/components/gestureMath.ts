export type GesturePoint = { x: number; y: number };

export const distanceBetween = (a: GesturePoint, b: GesturePoint) =>
  Math.hypot(a.x - b.x, a.y - b.y);

export const midpointBetween = (a: GesturePoint, b: GesturePoint): GesturePoint => ({
  x: (a.x + b.x) / 2,
  y: (a.y + b.y) / 2,
});

export const clampCamera = (value: number, min: number, max: number) =>
  Math.max(min, Math.min(max, value));
