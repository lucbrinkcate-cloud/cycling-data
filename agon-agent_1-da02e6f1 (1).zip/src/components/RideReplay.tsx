import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ChevronDown, Crosshair, HelpCircle, Minus, Pause, Play, Plus, RotateCcw, Sparkles, Trophy, Zap } from 'lucide-react';
import './premium-replay.css';
import { clampCamera, distanceBetween, midpointBetween, type GesturePoint } from './gestureMath';

type Sample={elapsed:number;distance:number;altitude:number;speed:number;power:number;heart_rate:number;cadence:number;latitude:number;longitude:number};
type Analysis={version?:number;efforts?:Array<{start:number;end:number;avgPower:number;peakPower:number;duration:number;score:number;zone:number;type:string;confidence:number}>;intervals:Array<{start:number;end:number;type:string}>;climbs:Array<{start:number;end:number;gain:number;distance:number;grade:number}>;sprints:Array<{index:number;power:number;at:number}>};
type Props={samples:Sample[];analysis:Analysis;active:number;ftp:number;onActive:(index:number)=>void};
type Point=Sample&{index:number;x:number;y:number};
type Effort={start:number;end:number;avg:number;peak:number;duration:number;score:number;zone:number;label:string;confidence:number};

const clamp=(n:number,min=0,max=1)=>Math.max(min,Math.min(max,n));
const mix=(a:number,b:number,t:number)=>a+(b-a)*t;
const time=(s:number)=>`${Math.floor(s/3600)}:${String(Math.floor(s%3600/60)).padStart(2,'0')}:${String(Math.floor(s%60)).padStart(2,'0')}`;
const powerStops=[0,.55,.75,.9,1.05,1.2,1.5];
const powerColors=['#68a9ff','#27d7c0','#8fe05b','#e8dc4e','#ffac45','#ff5a76','#a64de2'];
const speedColors=['#67afff','#28d4cd','#69dd82','#d3e052','#ffbd45','#ff754d','#de3e91'];
const colorIndex=(value:number,metric:'power'|'speed',maxSpeed:number,ftp:number)=>{const ratio=metric==='power'?value/ftp:value/Math.max(1,maxSpeed);const stops=metric==='power'?powerStops:[0,.25,.4,.55,.68,.82,1.01];let index=0;for(let i=1;i<stops.length;i++)if(ratio>=stops[i])index=i;return Math.min(6,index)};

function detectEfforts(samples:Sample[],ftp:number):Effort[]{
 if(samples.length<3||!ftp)return[];
 const valid=samples.filter(sample=>sample.power>0);
 if(valid.length<3)return[];
 const gaps=samples.slice(1).map((sample,i)=>Math.max(1,sample.elapsed-samples[i].elapsed)).sort((a,b)=>a-b);
 const resolution=gaps[Math.floor(gaps.length/2)]||1;
 const profiles=[
  {duration:15,min:1.45,label:'Sprint effort',zone:7},
  {duration:45,min:1.25,label:'Anaerobic effort',zone:6},
  {duration:180,min:1.08,label:'VO₂ max effort',zone:5},
  {duration:480,min:.95,label:'Threshold effort',zone:4},
  {duration:1200,min:.88,label:'Sweet spot effort',zone:4},
 ];
 const candidates:Effort[]=[];
 for(const profile of profiles){
  if(resolution>profile.duration*.65)continue;
  for(let start=0;start<samples.length-1;start++){
   let end=start+1;while(end<samples.length-1&&samples[end].elapsed-samples[start].elapsed<profile.duration)end++;
   const duration=samples[end].elapsed-samples[start].elapsed;if(duration<profile.duration*.75||duration>profile.duration*1.8)continue;
   let energy=0,total=0,peak=0;
   for(let i=start;i<end;i++){const dt=Math.max(1,samples[i+1].elapsed-samples[i].elapsed);energy+=(samples[i].power||0)*dt;total+=dt;peak=Math.max(peak,samples[i].power||0)}
   const avg=energy/Math.max(1,total),ratio=avg/ftp;
   if(ratio>=profile.min)candidates.push({start,end,avg,peak,duration,zone:profile.zone,label:profile.label,score:ratio*ratio*Math.sqrt(duration),confidence:Math.min(98,Math.round(80+(ratio-profile.min)*45+Math.min(10,duration/profile.duration*5)))})
  }
 }
 return candidates.sort((a,b)=>b.score-a.score).filter((effort,index,list)=>!list.slice(0,index).some(other=>{const overlap=Math.max(0,Math.min(effort.end,other.end)-Math.max(effort.start,other.start));return overlap/Math.max(1,effort.end-effort.start)>.35})).slice(0,5);
}

export default function RideReplay({samples,analysis,ftp,onActive}:Props){
 const [playing,setPlaying]=useState(true),[progress,setProgress]=useState(0),[rate,setRate]=useState(1),[metric,setMetric]=useState<'power'|'speed'>('power'),[zoom,setZoom]=useState(1),[pan,setPan]=useState({x:0,y:0}),[selectedEffort,setSelectedEffort]=useState<number|null>(null),[hoverZone,setHoverZone]=useState<number|null>(null),[legendOpen,setLegendOpen]=useState(false),[timelineHover,setTimelineHover]=useState<number|null>(null),[help,setHelp]=useState(false);
 const progressRef=useRef(0),lastRef=useRef<number|null>(null),frameRef=useRef(0),dragRef=useRef<{x:number;y:number;panX:number;panY:number}|null>(null);
 const pointersRef=useRef(new Map<number,GesturePoint>()),pinchRef=useRef<{distance:number;midpoint:GesturePoint;zoom:number;panX:number;panY:number}|null>(null);
 const points=useMemo<Point[]>(()=>{const geo=samples.map((s,index)=>({...s,index})).filter(s=>s.latitude&&s.longitude);if(!geo.length)return[];const xs=geo.map(s=>s.longitude),ys=geo.map(s=>s.latitude),minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(...ys),maxY=Math.max(...ys),pad=68;return geo.map(s=>({...s,x:pad+(s.longitude-minX)/(maxX-minX||1)*(900-pad*2),y:520-pad-(s.latitude-minY)/(maxY-minY||1)*(520-pad*2)}))},[samples]);
 const efforts=useMemo<Effort[]>(()=>analysis?.version===2&&Array.isArray(analysis.efforts)?analysis.efforts.map(effort=>({start:effort.start,end:effort.end,avg:effort.avgPower,peak:effort.peakPower,duration:effort.duration,score:effort.score,zone:effort.zone,label:effort.type,confidence:effort.confidence})):detectEfforts(samples,ftp),[samples,ftp,analysis]);
 const maxSpeed=useMemo(()=>Math.max(1,...samples.map(s=>s.speed||0)),[samples]);
 const segments=useMemo(()=>points.slice(1).map((point,i)=>({point,previous:points[i],start:i/Math.max(1,points.length-1),zone:colorIndex(metric==='power'?point.power:point.speed,metric,maxSpeed,ftp),effort:efforts.findIndex(e=>point.index>=e.start&&point.index<=e.end)})),[points,metric,maxSpeed,efforts,ftp]);
 const currentIndex=Math.min(samples.length-1,Math.round(progress*(samples.length-1))),current=samples[currentIndex]||samples[0],marker=points.reduce((best,p)=>Math.abs(p.index-currentIndex)<Math.abs(best.index-currentIndex)?p:best,points[0]);
 const currentZone=colorIndex(metric==='power'?(current?.power||0):(current?.speed||0),metric,maxSpeed,ftp);
 const seek=useCallback((value:number)=>{progressRef.current=clamp(value);setProgress(progressRef.current);onActive(Math.round(progressRef.current*(samples.length-1)))},[onActive,samples.length]);
 const animate=useCallback((now:number)=>{if(lastRef.current===null)lastRef.current=now;const delta=Math.min(50,now-lastRef.current);lastRef.current=now;progressRef.current=clamp(progressRef.current+delta/(42000/rate));setProgress(progressRef.current);onActive(Math.round(progressRef.current*(samples.length-1)));if(progressRef.current>=1){setPlaying(false);return}frameRef.current=requestAnimationFrame(animate)},[onActive,rate,samples.length]);
 useEffect(()=>{if(playing){lastRef.current=null;frameRef.current=requestAnimationFrame(animate)}return()=>cancelAnimationFrame(frameRef.current)},[playing,animate]);
 useEffect(()=>{const key=(e:KeyboardEvent)=>{if(e.target instanceof HTMLInputElement)return;if(e.code==='Space'){e.preventDefault();setPlaying(v=>!v)}if(e.key==='ArrowRight')seek(progressRef.current+.02);if(e.key==='ArrowLeft')seek(progressRef.current-.02);if(e.key==='+'||e.key==='=')setZoom(z=>Math.min(2.8,z+.2));if(e.key==='-')setZoom(z=>Math.max(1,z-.2));if(e.key==='Escape'){setZoom(1);setPan({x:0,y:0})}};window.addEventListener('keydown',key);return()=>window.removeEventListener('keydown',key)},[seek]);
 const camera=(next:number,focus?:Point)=>{const bounded=clampCamera(next,1,3.4);setZoom(bounded);if(focus)setPan({x:focus.x-450,y:focus.y-260});if(bounded<=1)setPan({x:0,y:0})};
 const viewW=990/zoom,viewH=570/zoom,centerX=450+pan.x,centerY=260+pan.y,viewBox=`${centerX-viewW/2} ${centerY-viewH/2} ${viewW} ${viewH}`;
 const colors=metric==='power'?powerColors:speedColors;
 const zones=metric==='power'?[['Z1',`<${Math.round(ftp*.55)} W`],['Z2',`${Math.round(ftp*.55)}–${Math.round(ftp*.75)} W`],['Z3',`${Math.round(ftp*.75)}–${Math.round(ftp*.9)} W`],['Z4',`${Math.round(ftp*.9)}–${Math.round(ftp*1.05)} W`],['Z5',`${Math.round(ftp*1.05)}–${Math.round(ftp*1.2)} W`],['Z6',`${Math.round(ftp*1.2)}–${Math.round(ftp*1.5)} W`],['Z7',`${Math.round(ftp*1.5)}+ W`]]:[['B1',`<${(maxSpeed*.25).toFixed(0)}`],['B2',`${(maxSpeed*.25).toFixed(0)}–${(maxSpeed*.4).toFixed(0)}`],['B3',`${(maxSpeed*.4).toFixed(0)}–${(maxSpeed*.55).toFixed(0)}`],['B4',`${(maxSpeed*.55).toFixed(0)}–${(maxSpeed*.68).toFixed(0)}`],['B5',`${(maxSpeed*.68).toFixed(0)}–${(maxSpeed*.82).toFixed(0)}`],['B6',`${(maxSpeed*.82).toFixed(0)}–${(maxSpeed*.93).toFixed(0)}`],['B7',`${(maxSpeed*.93).toFixed(0)}+`]];
 const focusEffort=(i:number)=>{const effort=efforts[i],point=points.reduce((best,p)=>Math.abs(p.index-effort.start)<Math.abs(best.index-effort.start)?p:best,points[0]);setSelectedEffort(i);setPlaying(false);seek(effort.start/Math.max(1,samples.length-1));camera(1.75,point)};
 const beginGesture=(id:number,point:GesturePoint)=>{pointersRef.current.set(id,point);const entries=[...pointersRef.current.values()];if(entries.length===1){dragRef.current={x:point.x,y:point.y,panX:pan.x,panY:pan.y}}else if(entries.length===2){dragRef.current=null;pinchRef.current={distance:distanceBetween(entries[0],entries[1]),midpoint:midpointBetween(entries[0],entries[1]),zoom,panX:pan.x,panY:pan.y}}};
 const moveGesture=(id:number,point:GesturePoint,width:number)=>{if(!pointersRef.current.has(id))return;pointersRef.current.set(id,point);const entries=[...pointersRef.current.values()];if(entries.length>=2&&pinchRef.current){const midpoint=midpointBetween(entries[0],entries[1]),distance=distanceBetween(entries[0],entries[1]),nextZoom=clampCamera(pinchRef.current.zoom*(distance/Math.max(1,pinchRef.current.distance)),1,3.4),scale=(990/nextZoom)/Math.max(1,width);setZoom(nextZoom);setPan({x:pinchRef.current.panX-(midpoint.x-pinchRef.current.midpoint.x)*scale,y:pinchRef.current.panY-(midpoint.y-pinchRef.current.midpoint.y)*scale});return}if(entries.length===1&&dragRef.current&&zoom>1){const scale=(990/zoom)/Math.max(1,width);setPan({x:dragRef.current.panX-(point.x-dragRef.current.x)*scale,y:dragRef.current.panY-(point.y-dragRef.current.y)*scale})}};
 const endGesture=(id:number)=>{pointersRef.current.delete(id);pinchRef.current=null;dragRef.current=null;const remaining=[...pointersRef.current.entries()];if(remaining.length===1){const [pointerId,point]=remaining[0];beginGesture(pointerId,point)}};
 return <section className="pr-shell">
  <div className="pr-map">
   <svg viewBox={viewBox} onDoubleClick={()=>camera(Math.min(3.4,zoom+.4),marker)} onWheel={e=>{e.preventDefault();const sensitivity=e.ctrlKey ? .012 : .0018;camera(zoom*Math.exp(-e.deltaY*sensitivity))}} onPointerDown={e=>{beginGesture(e.pointerId,{x:e.clientX,y:e.clientY});e.currentTarget.setPointerCapture(e.pointerId)}} onPointerMove={e=>moveGesture(e.pointerId,{x:e.clientX,y:e.clientY},e.currentTarget.getBoundingClientRect().width)} onPointerUp={e=>endGesture(e.pointerId)} onPointerCancel={e=>endGesture(e.pointerId)}>
    <defs><radialGradient id="prPaper"><stop stopColor="#e8e5de"/><stop offset="1" stopColor="#d8d7d1"/></radialGradient><filter id="prGlow"><feGaussianBlur stdDeviation="3"/></filter></defs><rect x="-700" y="-700" width="2300" height="1900" fill="url(#prPaper)"/>
    <g className="pr-context">{segments.map(({point,previous})=><line key={point.index} x1={previous.x} y1={previous.y} x2={point.x} y2={point.y}/>)}</g>
    {segments.map(({point,previous,start,zone,effort})=>{const partial=clamp((progress-start)*(points.length-1));if(partial<=0)return null;const dimmed=hoverZone!==null&&hoverZone!==zone;return <g key={point.index} className={dimmed?'pr-dim':''}>{effort>=0&&<line className={`pr-effort-halo ${selectedEffort===effort?'active':''}`} x1={previous.x} y1={previous.y} x2={mix(previous.x,point.x,partial)} y2={mix(previous.y,point.y,partial)}/>}<line className="pr-segment" x1={previous.x} y1={previous.y} x2={mix(previous.x,point.x,partial)} y2={mix(previous.y,point.y,partial)} stroke={colors[zone]}/></g>})}
    {efforts.map((effort,i)=>{const p=points.reduce((best,x)=>Math.abs(x.index-effort.start)<Math.abs(best.index-effort.start)?x:best,points[0]);return <g className={`pr-pin ${selectedEffort===i?'active':''}`} key={i} transform={`translate(${p.x} ${p.y})`} onClick={()=>focusEffort(i)}><line x1="2" y1="-2" x2="13" y2="-13"/><circle cx="18" cy="-18" r="10"/><text x="18" y="-15">{i+1}</text></g>})}
    {marker&&<g className="pr-rider" transform={`translate(${marker.x} ${marker.y})`}><circle r="15"/><circle r="5"/></g>}
   </svg>
   <div className="pr-top"><div className="pr-brand"><Sparkles/><span>RIDE INTELLIGENCE</span><small>LIVE ANALYSIS</small></div><div className="pr-toolbar"><div className="pr-toggle"><button className={metric==='power'?'active':''} onClick={()=>setMetric('power')}>POWER</button><button className={metric==='speed'?'active':''} onClick={()=>setMetric('speed')}>SPEED</button></div><button title="Zoom out" onClick={()=>camera(zoom-.2)}><Minus/></button><span>{Math.round(zoom*100)}%</span><button title="Zoom in" onClick={()=>camera(zoom+.2)}><Plus/></button><button title="Fit route" onClick={()=>camera(1)}><Crosshair/></button><button title="Keyboard shortcuts" onClick={()=>setHelp(v=>!v)}><HelpCircle/></button></div></div>
   {help&&<div className="pr-help"><b>SHORTCUTS</b><span><kbd>Space</kbd> Play / pause</span><span><kbd>← →</kbd> Seek ride</span><span><kbd>+ −</kbd> Zoom</span><span><kbd>Esc</kbd> Fit route</span></div>}
   <div className={`pr-legend ${legendOpen?'open':''}`}><button onClick={()=>setLegendOpen(v=>!v)}><i className="legend-spectrum"/><span>{metric==='power'?'ZONES':'BANDS'}</span><ChevronDown/></button>{legendOpen&&<div>{zones.map((zone,i)=><button className={currentZone===i?'current':''} onMouseEnter={()=>setHoverZone(i)} onMouseLeave={()=>setHoverZone(null)} key={zone[0]}><i style={{background:colors[i]}}/><b>{zone[0]}</b><span>{zone[1]}</span></button>)}</div>}</div>
   <div className="pr-hud"><div className="hero"><small>{metric==='power'?'LIVE POWER':'LIVE SPEED'}</small><b key={`${metric}-${currentIndex}`}>{metric==='power'?Math.round(current?.power||0):(current?.speed||0).toFixed(1)}</b><em>{metric==='power'?'WATTS':'KM/H'}</em><span style={{background:colors[currentZone]}}>{zones[currentZone]?.[0]}</span></div><div><small>DISTANCE</small><b>{current?.distance.toFixed(1)} <em>km</em></b></div><div><small>ELAPSED</small><b>{time(current?.elapsed||0)}</b></div></div>
  </div>
  <div className="pr-playback"><button onClick={()=>{seek(0);setPlaying(true)}}><RotateCcw/></button><button className="main" onClick={()=>setPlaying(v=>!v)}>{playing?<Pause/>:<Play/>}</button><div className="pr-time"><span>{time(current?.elapsed||0)}</span><span>{time(samples.at(-1)?.elapsed||0)}</span><div onPointerMove={e=>{const r=e.currentTarget.getBoundingClientRect();setTimelineHover(clamp((e.clientX-r.left)/r.width))}} onPointerLeave={()=>setTimelineHover(null)} onPointerDown={e=>{const r=e.currentTarget.getBoundingClientRect();setPlaying(false);seek((e.clientX-r.left)/r.width)}}><i style={{width:`${progress*100}%`}}/><b style={{left:`${progress*100}%`}}/>{timelineHover!==null&&<small style={{left:`${timelineHover*100}%`}}>{time(timelineHover*(samples.at(-1)?.elapsed||0))}</small>}{efforts.map((e,i)=><button key={i} style={{left:`${e.start/Math.max(1,samples.length-1)*100}%`}} onClick={event=>{event.stopPropagation();focusEffort(i)}}/>)}</div></div><div className="pr-rate">{[.5,1,2].map(v=><button className={rate===v?'active':''} onClick={()=>setRate(v)} key={v}>{v}×</button>)}</div></div>
  <div className="pr-efforts"><header><div><Trophy/><span><b>KEY EFFORTS</b><small>Best time-window power, ranked by intensity and duration</small></span></div><em>{efforts.length} VERIFIED · FTP {ftp} W</em></header><div className="pr-effort-grid">{efforts.map((e,i)=><button className={selectedEffort===i?'active':''} key={i} onClick={()=>focusEffort(i)}><div className="rank">{String(i+1).padStart(2,'0')}</div><div className="effort-copy"><span><i>Z{e.zone}</i>{e.label}</span><b>{Math.round(e.avg)}<small> W AVG</small></b><p>{time(e.duration)} · {samples[e.start]?.distance.toFixed(1)} km · {Math.round(e.avg/ftp*100)}% FTP</p></div><div className="confidence"><span>{e.confidence}%</span><small>CONFIDENCE</small><em>{Math.round(e.peak)} W PEAK</em></div></button>)}{!efforts.length&&<p className="pr-no-efforts">No qualifying sustained efforts were found for your {ftp} W FTP.</p>}</div></div>
 </section>
}
