import { useMemo } from 'react';
import { Gauge, Timer, TrendingUp, Zap } from 'lucide-react';
import './power-duration.css';

type Sample={elapsed:number;distance:number;speed:number;power:number};
type BestEffort={seconds:number;label:string;watts:number;wattsPerFtp:number;start:number;end:number;distance:number};

const durations=[
  {seconds:3,label:'3 sec'},{seconds:5,label:'5 sec'},{seconds:10,label:'10 sec'},
  {seconds:30,label:'30 sec'},{seconds:60,label:'1 min'},{seconds:180,label:'3 min'},
  {seconds:300,label:'5 min'},{seconds:600,label:'10 min'},{seconds:1200,label:'20 min'},
  {seconds:1800,label:'30 min'},{seconds:3600,label:'1 hour'},
];

function bestPower(samples:Sample[],duration:number,ftp:number):BestEffort|null{
  if(samples.length<2||(samples.at(-1)?.elapsed||0)<duration*.8)return null;
  let best:BestEffort|null=null;
  for(let start=0;start<samples.length-1;start++){
    let end=start+1;
    while(end<samples.length-1&&samples[end].elapsed-samples[start].elapsed<duration)end++;
    const windowDuration=samples[end].elapsed-samples[start].elapsed;
    if(windowDuration<duration*.8||windowDuration>duration*1.35)continue;
    let energy=0,total=0;
    for(let i=start;i<end;i++){
      const dt=Math.max(0,samples[i+1].elapsed-samples[i].elapsed);
      energy+=(samples[i].power||0)*dt;
      total+=dt;
    }
    const watts=Math.round(energy/Math.max(1,total));
    if(!best||watts>best.watts)best={seconds:duration,label:'',watts,wattsPerFtp:Math.round(watts/ftp*100),start,end,distance:samples[start].distance};
  }
  return best;
}

export default function PowerDurationInsights({samples,ftp,analysis,onSelect}:{samples:Sample[];ftp:number;analysis?:any;onSelect:(index:number)=>void}){
  const efforts=useMemo(()=>durations.map(item=>{const canonical=analysis?.version>=2&&analysis.powerCurve?.find((entry:any)=>entry.seconds===item.seconds);if(canonical)return {...canonical,label:item.label,wattsPerFtp:Math.round(canonical.watts/ftp*100)};const effort=bestPower(samples,item.seconds,ftp);return effort?{...effort,label:item.label}:null}),[samples,ftp,analysis]);
  const maxSpeed=useMemo(()=>samples.reduce((best,sample,index)=>sample.speed>best.speed?{speed:sample.speed,index,distance:sample.distance}:best,{speed:0,index:0,distance:0}),[samples]);
  const maxPower=useMemo(()=>samples.reduce((best,sample,index)=>sample.power>best.power?{power:sample.power,index,distance:sample.distance}:best,{power:0,index:0,distance:0}),[samples]);
  const available=efforts.filter(Boolean) as BestEffort[];
  return <section className="pd-card"><header><div><span className="pd-kicker"><TrendingUp/>RIDE INSIGHTS</span><h2>Power-duration curve</h2><p>Your strongest sustained power for each standard duration.</p>{analysis?.version!==2&&<p className="pd-warning">Legacy sparse data — re-upload the original FIT file for accurate peak and short-duration power.</p>}</div><div className="pd-peaks"><button onClick={()=>onSelect(maxPower.index)}><Zap/><span><small>PEAK POWER</small><b>{Math.round(maxPower.power)} <em>W</em></b><i>at {maxPower.distance.toFixed(1)} km</i></span></button><button onClick={()=>onSelect(maxSpeed.index)}><Gauge/><span><small>MAX SPEED</small><b>{maxSpeed.speed.toFixed(1)} <em>km/h</em></b><i>at {maxSpeed.distance.toFixed(1)} km</i></span></button></div></header><div className="pd-grid">{durations.map((duration,index)=>{const effort=efforts[index];return <button disabled={!effort} key={duration.seconds} onClick={()=>effort&&onSelect(effort.start)}><span><Timer/>{duration.label}</span>{effort?<><b>{effort.watts}<small> W</small></b><div><i style={{width:`${Math.min(100,effort.wattsPerFtp/1.6)}%`}}/><em>{effort.wattsPerFtp}% FTP</em></div><small>starts at {effort.distance.toFixed(1)} km</small></>:<><b className="unavailable">—</b><small>Ride too short</small></>}</button>})}</div>{available.length>1&&<footer><span>SPRINT</span><i/><span>ANAEROBIC</span><i/><span>VO₂ MAX</span><i/><span>THRESHOLD</span><i/><span>ENDURANCE</span></footer>}</section>
}
