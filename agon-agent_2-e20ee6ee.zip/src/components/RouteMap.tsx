import { useEffect, useMemo } from 'react';
import L from 'leaflet';
import { CircleMarker, MapContainer, Pane, Polyline, TileLayer, Tooltip, ZoomControl, useMap } from 'react-leaflet';
import type { Activity } from '../lib/activity';

const TILE_URL = 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png';
const TILE_ATTR = '&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a> &copy; <a href="https://carto.com/">CARTO</a>';

function FitBounds({ bounds }: { bounds: L.LatLngBoundsExpression }) {
  const map = useMap();
  useEffect(() => {
    map.fitBounds(bounds, { padding: [30, 30] });
    const t = setTimeout(() => map.invalidateSize(), 120);
    return () => clearTimeout(t);
  }, [map, bounds]);
  return null;
}

interface Props {
  activity: Activity;
  hoverIdx: number | null;
}

export default function RouteMap({ activity, hoverIdx }: Props) {
  // Colour-by-speed segments, chunked for Leaflet (SVG renderer friendly)
  const segments = useMemo(() => {
    const pts = activity.points;
    const target = 640; // total SVG paths
    const chunk = Math.max(2, Math.ceil(pts.length / target));
    const out: Array<{ positions: Array<[number, number]>; color: string; key: number }> = [];
    for (let i = 0; i < pts.length - 1; i += chunk) {
      const end = Math.min(pts.length - 1, i + chunk);
      const positions: Array<[number, number]> = [];
      for (let k = i; k <= end; k++) positions.push([pts[k].lat, pts[k].lng]);
      out.push({ positions, color: pts[Math.min(end, i + Math.floor(chunk / 2))].color, key: i });
    }
    return out;
  }, [activity]);

  const bounds = useMemo<L.LatLngBoundsExpression>(() => {
    const pts = activity.points;
    return L.latLngBounds(pts.map((p) => [p.lat, p.lng] as [number, number])).pad(0.04);
  }, [activity]);

  const casing = useMemo(
    () => activity.points.filter((_, i) => i % Math.max(1, Math.floor(activity.points.length / 1500)) === 0).map((p) => [p.lat, p.lng] as [number, number]),
    [activity],
  );

  const start = activity.points[0];
  const end = activity.points[activity.points.length - 1];
  const hovered = hoverIdx != null ? activity.points[hoverIdx] : null;

  return (
    <MapContainer
      key={activity.id}
      bounds={bounds}
      zoomControl={false}
      className="h-full w-full"
      style={{ background: '#070b10' }}
      attributionControl
    >
      <TileLayer url={TILE_URL} attribution={TILE_ATTR} opacity={0.82} />
      <ZoomControl position="bottomright" />
      <FitBounds bounds={bounds} />
      <Pane name="route" style={{ zIndex: 500 }}>
        <Polyline positions={casing} pathOptions={{ color: '#030509', weight: 8, opacity: 0.5, lineJoin: 'round', lineCap: 'round' }} interactive={false} />
        {segments.map((s) => (
          <Polyline
            key={s.key}
            positions={s.positions}
            pathOptions={{ color: s.color, weight: 4.2, opacity: 0.95, lineJoin: 'round', lineCap: 'round' }}
            interactive={false}
          />
        ))}
      </Pane>
      <Pane name="markers" style={{ zIndex: 600 }}>
        <CircleMarker center={[start.lat, start.lng]} radius={6.5} pathOptions={{ color: '#052e16', weight: 2, fillColor: '#b5f13e', fillOpacity: 1 }}>
          <Tooltip permanent direction="top" offset={[0, -9]} className="map-tag">Start</Tooltip>
        </CircleMarker>
        <CircleMarker center={[end.lat, end.lng]} radius={6.5} pathOptions={{ color: '#0b0f14', weight: 2, fillColor: '#f8fafc', fillOpacity: 1 }}>
          <Tooltip permanent direction="top" offset={[0, -9]} className="map-tag">Finish</Tooltip>
        </CircleMarker>
        {hovered && (
          <>
            <CircleMarker center={[hovered.lat, hovered.lng]} radius={13} pathOptions={{ color: '#b5f13e', weight: 1.6, opacity: 0.4, fillOpacity: 0 }} interactive={false} />
            <CircleMarker center={[hovered.lat, hovered.lng]} radius={6} pathOptions={{ color: '#05080c', weight: 2.4, fillColor: '#ffffff', fillOpacity: 1 }} interactive={false} />
          </>
        )}
      </Pane>
    </MapContainer>
  );
}
