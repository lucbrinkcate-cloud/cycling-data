// ---------------------------------------------------------------------------
// Route Reel — .FIT binary parsing (browser-side) via fit-file-parser
// ---------------------------------------------------------------------------
import { buildActivity, prettyFileName } from './activity';
import type { Activity, RawRecord, RawSession } from './activity';

let polyfilled = false;

/** fit-file-parser is a CJS lib that expects a few Node-ish globals. */
function ensurePolyfills() {
  if (polyfilled || typeof window === 'undefined') return;
  const w = window as unknown as Record<string, unknown>;
  w.global = w.global ?? window;
  if (!w.process) {
    w.process = { env: {}, browser: true, version: '', versions: {}, nextTick: (fn: () => void) => setTimeout(fn, 0) };
  }
  polyfilled = true;
}

async function loadParser(): Promise<any> {
  ensurePolyfills();
  const [mod, buf] = await Promise.all([import('fit-file-parser'), import('buffer')]);
  const w = window as unknown as Record<string, unknown>;
  if (!w.Buffer) w.Buffer = buf.Buffer;
  const FitParser = (mod as any).default ?? mod;
  return FitParser;
}

function toDegrees(v: number): number {
  // Garmin stores position in semicircles: deg = semi * (180 / 2^31)
  return Math.abs(v) > 180 ? (v * 180) / 2147483648 : v;
}

function coerceDate(v: unknown): Date | null {
  if (v instanceof Date) return v;
  if (typeof v === 'string' || typeof v === 'number') {
    const d = new Date(v);
    return isNaN(d.getTime()) ? null : d;
  }
  return null;
}

function deviceLabel(data: any): string | null {
  const fi = Array.isArray(data?.file_ids) ? data.file_ids[0] : data?.file_id;
  if (!fi) return null;
  const man = typeof fi.manufacturer === 'string' ? fi.manufacturer : null;
  const prod =
    typeof fi.product_name === 'string'
      ? fi.product_name
      : typeof fi.product === 'string'
        ? fi.product
        : null;
  const cap = (s: string) => s.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
  if (man && prod) return `${cap(man)} ${cap(prod)}`;
  if (man) return cap(man);
  return null;
}

export interface ParsedFit {
  activity: Activity;
  recordCount: number;
  messageTypes: string[];
}

export async function parseFitBuffer(
  buf: ArrayBuffer,
  fileName: string,
  fileSize: number | null,
): Promise<Activity> {
  const FitParser = await loadParser();

  const data: any = await new Promise((resolve, reject) => {
    const parser = new FitParser({
      force: true,
      speedUnit: 'm/s',
      lengthUnit: 'm',
      temperatureUnit: 'celsius',
      elapsedRecordField: true,
      mode: 'both',
    });
    parser.parse(buf, (err: unknown, result: unknown) => {
      if (err) reject(err instanceof Error ? err : new Error(String(err)));
      else resolve(result);
    });
  });

  const rawRecords: any[] = Array.isArray(data?.records) ? data.records : [];
  if (!rawRecords.length) {
    throw new Error('No record messages found — this may be a course or workout file rather than a recorded activity.');
  }

  const records: RawRecord[] = [];
  for (const r of rawRecords) {
    const ts = coerceDate(r?.timestamp);
    const latRaw = r?.position_lat;
    const lngRaw = r?.position_long;
    if (latRaw == null || lngRaw == null) continue;
    const lat = toDegrees(Number(latRaw));
    const lng = toDegrees(Number(lngRaw));
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) continue;
    records.push({
      timestamp: ts ?? new Date(0),
      lat,
      lng,
      altitude: typeof r.altitude === 'number' ? r.altitude : null,
      speed: typeof r.speed === 'number' ? r.speed : null,
      distance: typeof r.distance === 'number' ? r.distance : null,
      heart_rate: typeof r.heart_rate === 'number' ? r.heart_rate : null,
      power: typeof r.power === 'number' ? r.power : null,
    });
  }

  const session: RawSession | null = Array.isArray(data?.sessions) && data.sessions.length
    ? (data.sessions[0] as RawSession)
    : null;

  const name = prettyFileName(fileName) || 'Untitled activity';

  return buildActivity(records, {
    name,
    device: deviceLabel(data),
    fileName,
    fileSize,
    session,
  });
}

/** Load a bundled sample file through the exact same code path as uploads. */
export async function loadSample(url: string, label: string): Promise<Activity> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Could not load sample file (${res.status})`);
  const buf = await res.arrayBuffer();
  const fileName = url.split('/').pop() ?? 'sample.fit';
  const activity = await parseFitBuffer(buf, fileName, buf.byteLength);
  activity.name = label;
  return activity;
}
